package com.imageshrink.app

import android.text.format.Formatter
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.imageshrink.app.databinding.ItemResultBinding
import kotlin.math.roundToInt

class ResultAdapter(
    private val onOpen: (CompressResult) -> Unit,
    private val onShare: (CompressResult) -> Unit
) : RecyclerView.Adapter<ResultAdapter.VH>() {

    val items = mutableListOf<CompressResult>()

    class VH(val b: ItemResultBinding) : RecyclerView.ViewHolder(b.root)

    fun add(r: CompressResult) {
        items.add(0, r)
        notifyItemInserted(0)
    }

    fun clear() {
        items.clear()
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(ItemResultBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(h: VH, position: Int) {
        val r = items[position]
        val ctx = h.itemView.context
        h.b.name.text = r.name

        if (r.error || r.uri == null) {
            h.b.thumb.setImageResource(android.R.drawable.ic_dialog_alert)
            h.b.sizes.text = ctx.getString(R.string.failed)
            h.b.saved.visibility = View.GONE
            h.b.share.visibility = View.GONE
            h.b.root.setOnClickListener(null)
            h.b.root.isClickable = false
            return
        }

        h.b.thumb.setImageBitmap(r.thumb)
        val newText = Formatter.formatShortFileSize(ctx, r.newSize)
        if (r.originalSize > 0) {
            h.b.sizes.text = ctx.getString(
                R.string.sizes_fmt,
                Formatter.formatShortFileSize(ctx, r.originalSize),
                newText
            )
            val pct = ((1.0 - r.newSize.toDouble() / r.originalSize) * 100).roundToInt()
            h.b.saved.text =
                if (pct > 0) ctx.getString(R.string.saved_fmt, pct) else ctx.getString(R.string.no_gain)
        } else {
            h.b.sizes.text = newText
            h.b.saved.text = ""
        }
        h.b.saved.visibility = View.VISIBLE
        h.b.share.visibility = View.VISIBLE
        h.b.root.setOnClickListener { onOpen(r) }
        h.b.share.setOnClickListener { onShare(r) }
    }
}
