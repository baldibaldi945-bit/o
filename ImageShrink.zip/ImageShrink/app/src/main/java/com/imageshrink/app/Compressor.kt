package com.imageshrink.app

import android.content.ContentResolver
import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import java.io.ByteArrayOutputStream
import java.io.IOException
import kotlin.math.max
import kotlin.math.roundToInt

enum class OutFormat(val mime: String, val ext: String) {
    JPEG("image/jpeg", "jpg"),
    WEBP("image/webp", "webp")
}

data class Settings(val quality: Int, val format: OutFormat, val scalePercent: Int)

data class CompressResult(
    val name: String,
    val originalSize: Long,
    val newSize: Long,
    val uri: Uri?,
    val thumb: Bitmap?,
    val error: Boolean
)

object Compressor {

    @Suppress("DEPRECATION")
    fun compress(context: Context, source: Uri, s: Settings): CompressResult {
        val resolver = context.contentResolver
        var name = "image"
        var originalSize = -1L

        try {
            resolver.query(
                source,
                arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE),
                null, null, null
            )?.use { c ->
                if (c.moveToFirst()) {
                    val ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (ni >= 0 && !c.isNull(ni)) name = c.getString(ni)
                    val si = c.getColumnIndex(OpenableColumns.SIZE)
                    if (si >= 0 && !c.isNull(si)) originalSize = c.getLong(si)
                }
            }
        } catch (e: Exception) {
            // نكمل بالاسم الافتراضي
        }

        if (originalSize <= 0) {
            originalSize = try {
                resolver.openAssetFileDescriptor(source, "r")?.use { it.length } ?: -1L
            } catch (e: Exception) {
                -1L
            }
        }

        val base = name.substringBeforeLast('.', name)

        return try {
            // ImageDecoder يطبّق اتجاه الصورة (EXIF) تلقائيًا ويقرأ JPEG/PNG/WebP/HEIC/GIF
            var bmp = ImageDecoder.decodeBitmap(ImageDecoder.createSource(resolver, source)) { decoder, info, _ ->
                decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                if (s.scalePercent < 100) {
                    val w = max(1, (info.size.width * s.scalePercent / 100.0).roundToInt())
                    val h = max(1, (info.size.height * s.scalePercent / 100.0).roundToInt())
                    decoder.setTargetSize(w, h)
                }
            }

            // JPEG لا يدعم الشفافية: نضع خلفية بيضاء
            if (s.format == OutFormat.JPEG && bmp.hasAlpha()) {
                val flat = Bitmap.createBitmap(bmp.width, bmp.height, Bitmap.Config.ARGB_8888)
                Canvas(flat).apply {
                    drawColor(Color.WHITE)
                    drawBitmap(bmp, 0f, 0f, null)
                }
                bmp.recycle()
                bmp = flat
            }

            val thumb = makeThumb(bmp)

            val format = when (s.format) {
                OutFormat.JPEG -> Bitmap.CompressFormat.JPEG
                OutFormat.WEBP ->
                    if (Build.VERSION.SDK_INT >= 30) Bitmap.CompressFormat.WEBP_LOSSY
                    else Bitmap.CompressFormat.WEBP
            }

            val stream = ByteArrayOutputStream()
            if (!bmp.compress(format, s.quality, stream)) throw IOException("compress failed")
            bmp.recycle()

            val bytes = stream.toByteArray()
            val uri = save(resolver, "${base}_compressed.${s.format.ext}", s.format.mime, bytes)
            CompressResult(name, originalSize, bytes.size.toLong(), uri, thumb, false)
        } catch (t: Throwable) {
            CompressResult(name, originalSize, 0L, null, null, true)
        }
    }

    private fun makeThumb(bmp: Bitmap): Bitmap {
        val maxSide = 200
        val ratio = maxSide.toFloat() / max(bmp.width, bmp.height)
        if (ratio >= 1f) return bmp.copy(Bitmap.Config.ARGB_8888, false)
        return Bitmap.createScaledBitmap(
            bmp,
            max(1, (bmp.width * ratio).roundToInt()),
            max(1, (bmp.height * ratio).roundToInt()),
            true
        )
    }

    private fun save(resolver: ContentResolver, fileName: String, mime: String, bytes: ByteArray): Uri {
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, fileName)
            put(MediaStore.Images.Media.MIME_TYPE, mime)
            put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/ImageShrink")
            put(MediaStore.Images.Media.IS_PENDING, 1)
        }
        val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
            ?: throw IOException("insert failed")
        try {
            val out = resolver.openOutputStream(uri) ?: throw IOException("no output stream")
            out.use { it.write(bytes) }
            val done = ContentValues().apply { put(MediaStore.Images.Media.IS_PENDING, 0) }
            resolver.update(uri, done, null, null)
        } catch (e: Exception) {
            resolver.delete(uri, null, null)
            throw e
        }
        return uri
    }
}
